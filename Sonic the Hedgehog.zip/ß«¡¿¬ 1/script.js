$(document).ready(function () {
  $('.your-class').bxSlider();
});

  $('.sonic1').on('click', () => {
    location.href = '#block15';
  });
